#!/usr/bin/env bash
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

set -euo pipefail

CUR_DIR=${PWD##*/}  
CORE_DIR="orchestrator-core"

if [ $CUR_DIR != $CORE_DIR ]; then
  echo Not running from orchestrator-core directory.
  echo Switch directory to \orchestrator-core
  exit 1;
fi


mkdir -p ../dep/model/bert
pushd ../dep/model/bert >/dev/null

if [[ "$OSTYPE" == "darwin"* ]]; then
    python_v3=$(python3 ../../../../build/model_management/zip/get_model.py --model pretrained.20200924.microsoft.dte.00.06.en.onnx.zip)
else
    python_v3=$(python ../../../../build/model_management/zip/get_model.py --model pretrained.20200924.microsoft.dte.00.06.en.onnx.zip)
fi
