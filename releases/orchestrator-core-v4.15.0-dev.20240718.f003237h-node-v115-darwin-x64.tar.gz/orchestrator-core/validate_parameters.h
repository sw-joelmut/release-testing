// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once
#include <napi.h>
#include <memory>
#include "../oc_abi/orchestrator_abi.h"
using namespace std;
using namespace Napi;

namespace oc 
{
    class ValidateParameters
    {
        public:
            static string AddExample(const CallbackInfo& info, Napi::Object& obj);
            static string AddSnapshot(const CallbackInfo& info);
            static string AddBatch(const CallbackInfo& info, Napi::Uint8Array & examples_json, string & labels_prefix, batch_option & batch_option);
            static string CreateSnapshot(const CallbackInfo& info);
            static string GetExamples(const CallbackInfo& info, string & label_name, uint32_t & label_type);
            static string GetLabels(const CallbackInfo& info, uint32_t & label_type);
            static string RemoveExample(const CallbackInfo& info, Napi::Object& obj);
            static string Score(const CallbackInfo& info, string & text, uint32_t & label_type);
            static string ScoreBatch(const CallbackInfo& info, TextStrings & text, vector<string>& string_buffers, uint32_t & label_type);
            static string SetRuntimeParams(const CallbackInfo& info, string & config_or_path, bool & reset_all);

            static string StringMember(const Napi::Object& info, const string& prop, string& err);
            static string ObjectStringMember(const Napi::Object& info, const string& obj_prop_name, const string& prop, string& err);
            static string GetObjectMember(const Napi::Object& info, const string& obj_prop_name, Napi::Object& obj);
            
    };
}
