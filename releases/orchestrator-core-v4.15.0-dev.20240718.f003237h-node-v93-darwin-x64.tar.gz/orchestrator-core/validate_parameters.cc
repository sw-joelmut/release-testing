// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#include <iostream>
#include <iomanip>
#include <sstream>
#include <napi.h>

#include "validate_parameters.h"
#include "../oc_abi/orchestrator_abi.h"

#include "../utility/Debugging.h"

using namespace std;
using namespace Napi;

namespace oc 
{

    string ValidateParameters::Score(const CallbackInfo& info, string & text, uint32_t & label_type)
    {
        string result = "";
        size_t length = info.Length();
        label_type = static_cast<uint32_t>(1); // static_cast<uint32_t>(Intent);

        switch(length)
        {
            case 0:
                return "Score() must take a text string.";
            case 1:
            {
                if (!info[0].IsString())
                {
                    return "Score() must take string as first parameter.";
                }
                text = info[0].As<Napi::String>();
            }
            break;
            case 2:
            {
                if (!info[0].IsString() || !info[1].IsNumber())
                {
                    return "Score() takes string as first parameter and label type number as second parameter.";
                }
                text = info[0].As<Napi::String>();
                label_type = static_cast<uint32_t>(info[1].As<Napi::Number>());
            }
            break;
            default:
                return "Score() takes string as first parameter and label type number as second parameter.";
        }

        return result;
    }

    string ValidateParameters::AddBatch(const CallbackInfo& info, Napi::Uint8Array & batch_buffer, string & labels_prefix, batch_option & opt)
    {
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - ValidateParameters::AddBatch():" <<
            " ENTERING:" <<
            " info.Length()=" << info.Length() <<
            ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl
            ););
        string result = "";
        size_t length = info.Length();

        // Set defaults
        labels_prefix = "";
        opt = ::batch_option::BATCH_OPTION_ADD;

        switch(length)
        {
            case 1: // batch_buffer
            case 2: // labels_prefix
            case 3: // batch_option
                TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
                    "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - ValidateParameters::AddBatch():" <<
                    " case 3:" <<
                    " info.Length()=" << info.Length() <<
                    ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl
                    ););
                if (!info[0].As<Napi::Uint8Array>())
                {
                    return "addBatch() must take Array of bytes as first parameter (batch buffer).";
                }
                batch_buffer = info[0].As<Napi::Uint8Array>();
                // Uncomment to dump buffer.
                // for(size_t i = 0; i < batch_buffer.ByteLength(); ++i) {
                //         std::cerr << std::hex << std::setw(2) << (int)batch_buffer[i];
                //         std::cerr << (((i + 1) % 16 == 0) ? "\n" : " ");
                //     }
                // std::cerr << std::endl;

                // Handle Labels Prefix
                if (length > 1)
                {
                    if (!info[1].IsString())
                    {
                        return "addBatch() optionally takes a second parameter as string (labels prefix).";
                    }
                    labels_prefix = info[1].As<Napi::String>();
                }

                // Handle batch option
                if (length > 2)
                {
                    if (!info[2].IsNumber())
                    {
                        return "addBatch() optionally takes a third parameter as number [batch option 1 (add), 2 (reset)].";
                    }
                    int option = static_cast<uint32_t>(info[2].As<Napi::Number>());
                    if (option < 1 || option > 2)
                    {
                        return "addBatch() optionally takes a third parameter as number [batch option 1 (add), 2 (reset)], option is not 1 or 2.";
                    }
                    opt = static_cast<batch_option>(option);
                }
                break;
            default:
                return "addBatch() takes string as first parameter (and optional label prefix and batch option).";
        }
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - ValidateParameters::AddBatch():" <<
            " LEAVING:" <<
            " info.Length()=" << info.Length() <<
            ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl
            ););
        return result;
    }

    string ValidateParameters::ScoreBatch(const CallbackInfo& info, TextStrings & text, vector<string>& string_buffers, uint32_t & label_type)
    {
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - ValidateParameters::ScoreBatch():" <<
            " ENTERING" <<
            " info.Length()=" << info.Length()
            ););
        string result = "";
        size_t length = info.Length();
        label_type = static_cast<uint32_t>(1);
        switch(length)
        {
            case 0:
                TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
                    "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - ValidateParameters::ScoreBatch():" <<
                    " EXCEPTION" <<
                    " scoreBatch() must take a array of strings."
                    ););
                return "scoreBatch() must take a array of strings.";
            case 1:
            case 2:
            {
                {
                    if (!info[1].IsNumber())
                    {
                        return "scoreBatch() must take a numeric value for second parameter (intent=1, entity=2).";
                    }
                    uint32_t l = info[1].As<Number>(); 
                    // Validate?
                    // if (l < 0 || l > 2)
                    // {
                    //     return "scoreBatch() must take a numeric value [1 (intent), 2 (entity)].";
                    // }
                    label_type = l;
                }

                if (!info[0].As<Array>())
                {
                    return "scoreBatch() must take array of strings as first parameter.";
                }
                Array array = info[0].As<Array>();
                char**  textStringArray = new char*[array.Length()];
                text.count = array.Length();
                text.text = textStringArray;
                string_buffers.reserve(array.Length());
                for (size_t i = 0; i < array.Length(); i++) 
                {
                    Value value = array.Get(i).As<Napi::String>();

                    if (value.IsString())
                    {
                        string_buffers.push_back(value.ToString());
                        textStringArray[i] = const_cast<char *>(string_buffers.rbegin()->c_str());
                    }
                    else
                    {
                        delete [] textStringArray;
                        return "ScoreBatch() must take array of of type string as first parameter.";
                    }
                }

            }
            break;
            default:
                return "ScoreBatch() takes string as first parameter and label type number as second parameter.";
        }

        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - ValidateParameters::ScoreBatch():" <<
            " LEAVING" <<
            " info.Length()=" << info.Length()
            ););
        return result;
    }

    string ValidateParameters::AddSnapshot(const CallbackInfo& info)
    {
        string result = "";
        size_t length = info.Length();

        if (info.Length() == 0)
        {
            return "AddSnapshot() requires snapshot buffer.";
        }
        if (nullptr == info[0].As<Napi::Uint8Array>())
        {
            return "AddSnapshot() requires Array of bytes as first.";
        }

        if (length > 1 && !info[1].IsString())
        {
            return "AddSnapshot() requires string as second parameter.";
        }
        
        return "";
    }

    string ValidateParameters::AddExample(const CallbackInfo& info, Napi::Object& obj)
    {
        string result = "";
        size_t length = info.Length();
        if ((length <= 0) || (length > 2))
            return "Arguments should include example and optional callback expected.";

        if (!info[0].IsObject())
            return "Object with 'labels', 'text' (optionally 'embedding') expected as first parameter.";

        const Napi::Object example = info[0].As<Napi::Object>();

        // labels is currently accepted in two ways.
        //   labels is a string.  This is interpreted as the labels name.
        //   labels is an object.  Within the labels object, is a field called name.
        // In the future, we may support:
        //   labels as an array of string
        //   labels as an array of object
        string err;
        ValidateParameters::StringMember(example, "labels", err);
        if (!err.empty())
        {
            if (!example.Has("labels") && !example.Has("label"))
                return "Must have a single label or array of labels.";
        }

        // text
        ValidateParameters::StringMember(example, "text", err);
        if (!err.empty())
            return err;

        return result;
    }

    string ValidateParameters::RemoveExample(const CallbackInfo& info, Napi::Object& obj)
    {
        return ValidateParameters::AddExample(info, obj);
    }

    // GetExamples takes optional parameters:
    //  string label_name
    //  int label_type
    string ValidateParameters::GetExamples(const CallbackInfo& info, string & label_name, uint32_t & label_type)
    {
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - D - ValidateParameters::GetExamples():" <<
            " info.Length()=" << info.Length() <<
            ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl
            ););
        string result = "";
        size_t length = info.Length();
        switch(length)
        {
            case 0:
                break;
            case 1:
                if (!info[0].IsString() && !info[0].IsNumber())
                {
                    return "GetExamples() must take string or number as first parameter.";
                }
                if (info[0].IsString())
                {
                    label_name = info[0].As<Napi::String>();
                }
                else if (info[0].IsNumber())
                {
                    label_type = static_cast<uint32_t>(info[0].As<Napi::Number>());
                }
                break;
            case 2:
                if (!info[0].IsString() || !info[1].IsNumber())
                {
                    return "GetExamples() takes string as first parameter and label type number as second parameter.";
                }
                label_name = info[0].As<Napi::String>();
                label_type = static_cast<uint32_t>(info[1].As<Napi::Number>());
                break;
            default:
                return "GetExamples() takes string as first parameter and label type number as second parameter.";
        }
        return result;
    }

    // GetLabels takes optional parameters:
    //  int label_type
    string ValidateParameters::GetLabels(const CallbackInfo& info, uint32_t & label_type)
    {
        
        string result = "";
        size_t length = info.Length();
        switch(length)
        {
            case 0:
                break;
            case 1:
                if (!info[0].IsNumber())
                {
                    return "GetLabels() takes a label type (number) as first parameter.";
                }
                label_type = static_cast<uint32_t>(info[0].As<Napi::Number>().Uint32Value());
                break;
            default:
                return "GetLabels() takes label type (number) as first parameter.";
        }
        return result;
    }

    string ValidateParameters::CreateSnapshot(const CallbackInfo& info)
    {
        string result = "";
        size_t length = info.Length();

        if ((length > 1) || (length == 1 && !info[0].IsBoolean()))
        {
            return "CreateSnapshot() takes single boolean 'include_examples' as parameter.";
        }

        return result;
    }

    string ValidateParameters::SetRuntimeParams(const CallbackInfo& info, string & config_or_path, bool & reset_all)
    {
        string result = "";
        size_t length = info.Length();

        if (length == 0 || !info[0].IsString() || (length > 1 && !info[1].IsBoolean()))
            return "setRuntimeParams() takes string 'config_or_path' as parameter and optional boolean 'reset_all'.";

        config_or_path = info[0].As<Napi::String>();
        reset_all = info[1].As<Napi::Boolean>();

        return result;
    }


        // Check if the object has a named string property.
    string ValidateParameters::StringMember(const Napi::Object& info, const string& prop, string& err) 
    {
        string result = "";
        err = "";
        if (info.Has(prop)) {
            auto p = info.Get(prop);
            if (!p.IsString()) {
                err = "Property '" + prop + "' expected to be string.";
            }
            else {
                auto str = p.As<Napi::String>();
                result = str.Utf8Value();
            }
        }
        else {
            err = "String property '" + prop + "' expected to be set.";
        }
        return result;
    }

    string ValidateParameters::GetObjectMember(const Napi::Object& info, const string& obj_prop_name, Napi::Object& obj)
    {
        string result = "";
        if (info.Has(obj_prop_name))
        {
            auto incoming_obj = info.Get(obj_prop_name);
            if (!incoming_obj.IsObject())
            {
                result = "Object '" + obj_prop_name + "' expected to be an object.";
            }
            else
            {
                obj = (Napi::Object&) incoming_obj;
            }
        }
        else {
            result = "Property '" + obj_prop_name + "' expected to be set to an object.";
        }
        return result;
    }



    string ValidateParameters::ObjectStringMember(const Napi::Object& info, const string& obj_prop_name, const string& prop, string& err) 
    {
        string result = "";
        if (info.Has(obj_prop_name)) 
        {
            auto obj = info.Get(obj_prop_name);
            if (!obj.IsObject()) 
            {
                err = "Object '" + obj_prop_name + "' expected to be an object.";
            }
            else 
            {
                Napi::Object & cur = (Napi::Object &) obj;
                if (cur.Has(prop)) 
                {
                    auto p = cur.Get(prop);
                    if (p.IsString())
                    {
                        auto str = obj.As<Napi::String>();
                        return str;
                    }
                    err = obj_prop_name + " expected to contain string property " + prop;
                }
                else
                {
                    err = obj_prop_name + " expected to contain string property " + prop;
                }
            }
        }
        else {
            err = "Property '" + obj_prop_name + "' expected to be set to an object.";
        }
        return result;
    }





}
