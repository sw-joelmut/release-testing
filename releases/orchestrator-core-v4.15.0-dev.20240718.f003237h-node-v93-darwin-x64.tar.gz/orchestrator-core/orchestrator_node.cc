// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#include <iostream>
#include <sstream>
#include <memory>

#include "orchestrator_node.h"
#include "label_resolver_node.h"
#include "load_nlr.h"
#include "../oc_abi/orchestrator_abi.h"

#include "../utility/Debugging.h"

using namespace std;
using namespace Napi;

namespace oc 
{
    FunctionReference OrchestratorNode::constructor;

    Object OrchestratorNode::init(Napi::Env env, Object exports) 
    {
        HandleScope scope(env);

        auto func = DefineClass(env, "Orchestrator",
            {
                InstanceMethod("load", &OrchestratorNode::Load),
                InstanceMethod("loadAsync", &OrchestratorNode::LoadAsync),
                InstanceMethod("createLabelResolver", &OrchestratorNode::CreateLabelResolver),
            });

        constructor = Persistent(func);
        constructor.SuppressDestruct();
        exports.Set("Orchestrator", func);

        return exports;
    }

    OrchestratorNode::OrchestratorNode(const CallbackInfo& info) :
        ObjectWrap<OrchestratorNode>(info)
    {
    }

    Napi::Value OrchestratorNode::Load(const Napi::CallbackInfo& info)
    {
        TRACE(std::cerr << "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - OrchestratorNode::Load() called:" <<
            " info.Length()=" << info.Length() <<
            ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl;)
        Napi::Env env = info.Env();
        HandleScope scope(env);
        auto length = info.Length();
        string intentBaseModelPathOrConfig = "";
        string entityBaseModelPathOrConfig = "";

        if (length > 0)
        {
            if (!info[0].IsString())
            {
                TRACE(std::cerr << "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - OrchestratorNode::Load():" <<
                    " info.Length()=" << info.Length() <<
                    ", !info[0].IsString() == true" <<
                    ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl;)
                TypeError::New(env, "load() method must provide valid path or config to a base model.").ThrowAsJavaScriptException();
                return info.Env().Undefined();
            }
            intentBaseModelPathOrConfig = info[0].As<Napi::String>();
        }
        if (length > 1)
        {
            if (!info[1].IsString())
            {
                TRACE(std::cerr << "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - OrchestratorNode::Load():" <<
                    " info.Length()=" << info.Length() <<
                    ", !info[1].IsString() == true" <<
                    ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl;)
                TypeError::New(env, "load() method must provide valid path or config to a base model.").ThrowAsJavaScriptException();
                return info.Env().Undefined();
            }
            entityBaseModelPathOrConfig = info[1].As<Napi::String>();
        }

        oc_error_t err = 0;
        TRACE(std::cerr << "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - OrchestratorNode::Load():" <<
            " info.Length()=" << info.Length() <<
            ", ready to call ::CreateOrchestratorAbi()" <<
            ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl;)
        if (length > 1)
        {
            _orchestrator = ::CreateOrchestratorAbiIntentEntity(intentBaseModelPathOrConfig.c_str(), entityBaseModelPathOrConfig.c_str(), &err);
        }
        else
        {
            _orchestrator = ::CreateOrchestratorAbi(intentBaseModelPathOrConfig.c_str(), &err);
        }
        TRACE(std::cerr << "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - OrchestratorNode::Load():" <<
            " info.Length()=" << info.Length() <<
            ", finished calling ::CreateOrchestratorAbi()" <<
            ", err=" << err <<
            ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl;)
        if (err != 0)
        {
            string err_msg = ::ErrorMessage(err);
            ::ErrorRelease(err);
            TRACE(std::cerr << "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - OrchestratorNode::Load():" <<
                " info.Length()=" << info.Length() <<
                ", err_msg=" << err_msg <<
                ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl;)
            _orchestrator = 0;
            TypeError::New(env, err_msg.c_str()).ThrowAsJavaScriptException();
            return Boolean::New(env, false);
            
        }
        TRACE(std::cerr << "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - OrchestratorNode::Load() ready to return:" <<
            " info.Length()=" << info.Length() <<
            ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl;)

        return Boolean::New(env, true);
    }

    Napi::Value OrchestratorNode::LoadAsync(const Napi::CallbackInfo& info)
    {
        Napi::Env env = info.Env();
        HandleScope scope(env);
        auto length = info.Length();
        string intentBaseModelPathOrConfig = "";
        string entityBaseModelPathOrConfig = "";

        if (length > 0)
        {
            if (!info[0].IsString())
            {
                TypeError::New(env, "loadAsync() method must provide valid path or config to a base model.").ThrowAsJavaScriptException();
                return info.Env().Undefined();
            }
            intentBaseModelPathOrConfig = info[0].As<Napi::String>();
        }
        if (length > 1)
        {
            if (!info[1].IsString())
            {
                TypeError::New(env, "loadAsync() method must provide valid path or config to a base model.").ThrowAsJavaScriptException();
                return info.Env().Undefined();
            }
            entityBaseModelPathOrConfig = info[1].As<Napi::String>();
        }
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - OrchestratorNode::LoadAsync():" <<
            " length=" << length <<
            ", intentBaseModelPathOrConfig=" << intentBaseModelPathOrConfig <<
            ", entityBaseModelPathOrConfig=" << entityBaseModelPathOrConfig);
        );
        // Call async API
        LoadNlrWorker* calc =
            (length > 1)  ?
            new LoadNlrWorker(env, intentBaseModelPathOrConfig, entityBaseModelPathOrConfig, *this):
            new LoadNlrWorker(env, intentBaseModelPathOrConfig, *this);
        auto promise = calc->GetPromise();
        calc->Queue();

        return promise;
    }



    // Optional Parameters:
    //    -  use_compact_embeddings 
    //    -  snapshot
    //    -  snapshot, use_compact_embeddings 
    Napi::Value OrchestratorNode::CreateLabelResolver(const Napi::CallbackInfo& info)
    {
        auto snapshot = make_shared<vector<uint8_t>>();
        auto parms = new LabelResolverParams();
        parms->orchestrator = _orchestrator;
        TRACE(std::cerr << "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - OrchestratorNode::CreateLabelResolver():" <<
            " info.Length()=" << info.Length() <<
            ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl;)
        switch (info.Length()) 
        {
            case 0:
                break;
            case 1: // use_compact_embeddings (snapshot?)
                if (info[0].IsTypedArray()) 
                {
                    auto buffer = info[0].As<Napi::Uint8Array>();
                    TRACE(std::cerr << "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - OrchestratorNode::CreateLabelResolver():" <<
                        " buffer.ByteLength()=" << buffer.ByteLength() <<
                        ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl;)
                    parms->snapshot.insert(parms->snapshot.end(), buffer.Data(), buffer.Data() + buffer.ByteLength());
                }
                else
                {
                    TRACE(std::cerr << "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - OrchestratorNode::CreateLabelResolver():" <<
                        " info[0].IsTypedArray()=" << info[0].IsTypedArray() <<
                        ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl;)
                    Napi::Error::New(info.Env(), "Expected a snapshot (uint8_t buffer).")
                        .ThrowAsJavaScriptException();
                    return info.Env().Undefined();
                }
                break;

            default:
                Napi::Error::New(info.Env(), "Expected a optional snapshot (uint8_t buffer)")
                    .ThrowAsJavaScriptException();
                return info.Env().Undefined();
        }

        // Pass orchestrator for construction of LabelResolver
        
        auto orch = Napi::External<LabelResolverParams>::New(
            info.Env(),
            parms);
        TRACE(std::cerr << "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - OrchestratorNode::CreateLabelResolver():" <<
            " orch=" << orch <<
            ", FILE=" << __FILE__ << ", LINE=" << __LINE__ << std::endl;)

        auto result =  LabelResolverNode::NewInstance(info.Env(), orch);
        return result;
    }

    // Logically internal method to set the orchestrator object.
    bool OrchestratorNode::SetOrchestrator(orchestrator_t & orchestrator)
    {
        _orchestrator = orchestrator;
        return true;
    }
}  // namespace oc
