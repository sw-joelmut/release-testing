// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

function buf2hex(buffer) { // buffer is an ArrayBuffer
  return Array.prototype.map.call(new Uint8Array(buffer), x => ('00' + x.toString(16)).slice(-2)).join(' ');
}

const oc = require('./orchestrator-core.node');
const util = require('util')

async function addExamples() {
  console.log('---- Create Orchestrator..')
  const orchestrator = new oc.Orchestrator();

  console.log('---- Loading NLR..')
  const load_result = orchestrator.load('../dep/model/roberta'); // Return boolean, separate load.
  if (load_result === false)
  {
      console.log('ERROR: Loading NLR failed!!');
  }

  console.log('---- Creating labeler..');
  let labeler = orchestrator.createLabelResolver(); 
  
  let config = labeler.getConfigJson();
  console.log(config)

  let r = labeler.setRuntimeParams(config, true);
  if (r==true)
  {
    console.log("SUCCESS: set runtime params successfully!")
  }
  else
  {
    console.log("ERROR: Could not set runtime params!")
  }

  const example = { 
    text: 'book a flight to miami.',
    label: { 
            name: 'travel',
            span: { 
                length: 5, 
                offset: 0 
            },
            label_type: 1
        },
    };
    const example4 =  {
        text: 'book a flight to miami.',
        labels: [ 
            { name: 'travel', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'taco', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'bell', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'kirkland', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'hungry', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'hotsauce', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'tomato', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'chocolate', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'katsuchicken', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'pulledport', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'hotpot', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'hotoil', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'dumplings', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'flavor', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'meat', label_type: 1, span: { offset: 0, length: 0 } },
            { name: 'tender', label_type: 1, span: { offset: 0, length: 0 } }
                ] };

  
  console.log('---- Adding example COMPLEX..');
  var val = labeler.addExample(example4);
  if (val == true)
  {
      console.log('SUCCESS: added example - 0!');
  }

  console.log('---- Adding Labels array.')
  const example_multi_single = { 
    text: 'another book a flight to miami.',
    labels: [{ 
            name: 'travel',
            span: { 
                length: 5, 
                offset: 0 
            },
            label_type: 1
        }],
    };
  val = labeler.addExample(example_multi_single);
  if (val == true)
  {
      console.log('SUCCESS: added example - 1!');
  }
  const example_multi_label = { 
    text: 'seattle flight.',
    labels: [{ 
            name: 'travel',
            span: { 
                length: 6, 
                offset: 9 
            },
            label_type: 1
        },
        { 
            name: 'city',
            span: { 
                length: 7, 
                offset: 0 
            },
            label_type: 1
        }
        ],
    };
  val = labeler.addExample(example_multi_label);
  if (val == true)
  {
      console.log('SUCCESS: added example - 2!');
  }
  const example2 = { 
      label: 'schedule', 
      text: 'when is my next appointment?',
      };
  val = labeler.addExample(example2);
  if (val == true)
  {
      console.log('SUCCESS: added example - 3!');
  }
  const example3 = { 
      label: 'greeting', 
      text: 'hello there!',
      };
  val = labeler.addExample(example3);
  if (val == true)
  {
      console.log('SUCCESS: added example3 - 4!');
  }

  // Add batch
  var batch_json = `
            {
                "examples":
                [
                {
                    "text": "Is Not Time to Be Young showing at AMC threaters",
                    "intents":
                    [
                        {
                            "name": "movie",
                            "offset" : 0,
                            "length": 0
                        },
                        {
                            "name": "question",
                            "offset": 0,
                            "length": 0
                        }
                    ],
                    "entities":
                    [
                        {
                            "name": "movie_name",
                            "offset": 3,
                            "length": 20
                        },
                        {
                            "name": "location_name",
                            "offset": 35,
                            "length": 13
                        }
                    ]
                }
                ]
            }`


  var num_new_elems = labeler.addBatch(batch_json);
  console.log('---- Add Batch returned ' + num_new_elems)
  var exles = labeler.getExamples();
  console.log(util.inspect(exles, true, null, true /* enable colors */));


  //
  // Score
  //
  console.log('---- Scoring')
  var results = labeler.score("hey");
  console.log(util.inspect(results, true, null, true /* enable colors */));

  console.log('---- Scoring Batch')
  var batch_text = [ 'hey', 'what is my schedule?', 'book a flight' ];
  var batch_results = labeler.scoreBatch(batch_text, 1);
  console.log(util.inspect(batch_results, true, null, true /* enable colors */));

  //
  // Score
  //
  console.log('---- Creating Snapshot')
  var snapshot = labeler.createSnapshot();
  console.log('SUCCESS: created snapshot!');

  console.log('---- Going to create labeler #2');
  let labeler2 = orchestrator.createLabelResolver(snapshot); 
  console.log('SUCCESS: created Labeler #2.');

  //
  // Get Examples
  //
  console.log('---- Getting examples')
  let examples = labeler2.getExamples();
  console.log(util.inspect(examples, true, null, true /* enable colors */));
  // 
  // Remove Example
  //
  console.log('---- Removing examples')
  labeler2.removeExample(example3);
  examples = labeler2.getExamples();
  console.log(util.inspect(examples, true, null, true /* enable colors */));

  //
  // Get Labels
  //
  console.log('---- Get Labels');
  var labels = labeler2.getLabels();
  console.log(util.inspect(labels, true, null, true /* enable colors */));

  //
  // Get Intent Labels
  //
  console.log('---- Get Intent Labels');
  var labels = labeler2.getLabels(1);
  console.log(util.inspect(labels, true, null, true /* enable colors */));
}

addExamples();

// ==== TODO-CANNOT-GET-embedding-FROM-ABI ==== const readline = require('readline');
// ==== TODO-CANNOT-GET-embedding-FROM-ABI ==== const rl = readline.createInterface({ input: process.stdin, output: process.stdout});
// ==== TODO-CANNOT-GET-embedding-FROM-ABI ==== 
// ==== TODO-CANNOT-GET-embedding-FROM-ABI ==== rl.question('>', (answer) => {
// ==== TODO-CANNOT-GET-embedding-FROM-ABI ====   console.log('Completed embedding:')
// ==== TODO-CANNOT-GET-embedding-FROM-ABI ====   console.log(buf2hex(embedding))
// ==== TODO-CANNOT-GET-embedding-FROM-ABI ====   rl.close();
// ==== TODO-CANNOT-GET-embedding-FROM-ABI ==== });
