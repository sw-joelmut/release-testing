// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const fs = require('fs');
const assert = require('assert');
const oc = require('../orchestrator-core.node');
const path = require('path');
require('fast-text-encoding'); 
const util = require('util')

// Finds onnx model
// Begins looking "path_depth" directories from current directory.
var findOnnxDir = function(path_depth, baseModelName='pretrained.20200924.microsoft.dte.00.06.en.onnx') {
  var cwd = process.cwd();
  var i;
  const sep = (cwd.includes('\\') ? '\\' : '/');
  for (i = 0; i< path_depth; i++)
  {
      var dtemp = cwd.split(sep);
      dtemp.pop();
      cwd = dtemp.join(sep);
  }

  var model_dir = null;
  function validateConfigFile(model_dir, baseModelName) {
      // console.log('ONNX: Found onnx file in ' + model_dir);
      try{
        var config_file = path.join(model_dir, 'config.json');
        // console.log('  => Seeing if ' + config_file + ' exists..')
        if (fs.existsSync(config_file)) {
            // console.log('      This file exists: ' + config_file);
            
            var jsonData = fs.readFileSync(config_file, 'utf8');
            const config = JSON.parse(jsonData); 
            if (config.hasOwnProperty('VocabFile')
                && config.hasOwnProperty('ModelFile') && config.hasOwnProperty('Name')
                && config.Name == baseModelName) {
                // console.log('     => VALID! Found model ' + baseModelName);
                return true;
            }
            // console.log('     => Invalid config!');
            return false;
        }
        // console.log('  => Does not exist: ' + config_file );
        return false;
      } catch(err) {
          // console.log('  => Does not exist EXCEPT!: ' + err );
          return false;
      }
      return false;
  }

  function findModel(cwd, baseModelName) {
     fs.readdirSync(cwd).find( (dirInner) => {
        dirInner = cwd + sep + dirInner;
        var stat = fs.statSync(dirInner);

        if (stat.isDirectory() && 
            !dirInner.endsWith("node_modules") &&  // Don't bother looking in node_modules
            !dirInner.endsWith("TestResults")) {  // Don't bother looking in TestResults
            return findModel(dirInner, baseModelName);
        } 

        if (stat.isFile() && dirInner.endsWith(".onnx")) {
            var dtemp = dirInner.split(sep);
            dtemp.pop();
            dirInner = dtemp.join(sep);
            if (validateConfigFile(dirInner, baseModelName)) {
              model_dir = dirInner;
              return true;
            }
            return false;
        }
        return false;
    });
    return model_dir;
  }

  findModel(cwd, baseModelName);
  return model_dir;
};

describe('Orchestrator', function () {

    // Set up a "test fixture" with loaded model.
    // Executed once for this overall suite.
    before(function () {
        this.timeout(1000000);
        this.orchestrator = new oc.Orchestrator();
        var onnx_dir = findOnnxDir(1, );
        console.log(`DEBUGGING - nodejs - orchestrator-core: Orchestrator.before(): onnx_dir=${onnx_dir}`);
        fs.readdirSync(onnx_dir).forEach(file => {
            console.log(`DEBUGGING - nodejs - orchestrator-core: Orchestrator.before(): file=${file}`);
          });

        const load_result = this.orchestrator.load(onnx_dir);
        console.log(`DEBUGGING - nodejs - orchestrator-core: Orchestrator.before() DONE: load_result=${load_result}`);

        assert.strictEqual(load_result, true);

        console.log(`DEBUGGING - nodejs - orchestrator-core: Orchestrator.before() DONE: onnx_dir=${onnx_dir}`);
    });

    it('00) Create BLU file example -- VA.txt', function () {
        this.timeout(10000000);
        // Arrange
        var orc = new oc.Orchestrator();
        var onnx_dir = findOnnxDir(1);
        orc.load(onnx_dir);
        var labeler = orc.createLabelResolver();
        try {
            const snapshotPath = path.join(__dirname, 'snapshot', 'VA.txt');
            var data = fs.readFileSync(snapshotPath, 'utf8');
            console.log('OPENING FILE ' + snapshotPath);
            var lines = data.split(/\r?\n/);
            var skipfirst = false;
            for (let line of lines) {
                if (!line.trim()) {
                    continue;
                }
                // console.log(line);
                tokens = line.split('\t');
                if (skipfirst)
                    skipfirst = false;
                else
                {
                    var example = { 
                        label: tokens[0], 
                        text: tokens[1],
                        };
                    var result = labeler.addExample(example);
                }
            }
            var snapshot = labeler.createSnapshot();
            console.log('Created snapshot!');
            const outputSnapshotPath = path.join(__dirname, 'snapshot', 'VA_snapshot.blu');
            fs.writeFile(outputSnapshotPath, snapshot, (err) => {
                if (err) { throw err; }
                console.log('Snapshot saved!' + outputSnapshotPath);
            });
        } catch(e) {
            console.log('Error:', e.stack);
        }
    });
    it('01) Create BLU file example -- Email.txt', function () {
        this.timeout(1000000);
        // Arrange
        var orc = new oc.Orchestrator();
        var onnx_dir = findOnnxDir(1);
        orc.load(onnx_dir);
        var labeler = orc.createLabelResolver();
        try {
            const snapshotPath = path.join(__dirname, 'snapshot', 'Email.txt');
            var data = fs.readFileSync(snapshotPath, 'utf8');
            console.log('OPENING FILE ' + snapshotPath);
            var lines = data.split(/\r?\n/);
            var skipfirst = false;
            for (let line of lines) {
                if (!line.trim()) {
                    continue;
                }
                // console.log(line);
                tokens = line.split('\t');
                if (skipfirst)
                    skipfirst = false;
                else
                {
                    var example = { 
                        label: tokens[0], 
                        text: tokens[1],
                        };
                    var result = labeler.addExample(example);
                }
            }
            var snapshot = labeler.createSnapshot();
            console.log('Created snapshot!');
            const outputSnapshotPath = path.join(__dirname, 'snapshot', 'Email_snapshot.blu');
            fs.writeFile(outputSnapshotPath, snapshot, (err) => {
                if (err) { throw err; }
                console.log('Snapshot saved!' + outputSnapshotPath);
            });
        } catch(e) {
            console.log('Error:', e.stack);
        }
    });
    it('02) Create BLU file example -- EmailTest.txt', function () {
        this.timeout(1000000);
        // Arrange
        var orc = new oc.Orchestrator();
        var onnx_dir = findOnnxDir(1);
        orc.load(onnx_dir);
        var labeler = orc.createLabelResolver();
        try {
            const snapshotPath = path.join(__dirname, 'snapshot', 'EmailTest.txt');
            var data = fs.readFileSync(snapshotPath, 'utf8');
            console.log('OPENING FILE ' + snapshotPath);
            var lines = data.split(/\r?\n/);
            var skipfirst = false;
            for (let line of lines) {
                if (!line.trim()) {
                    continue;
                }
                // console.log(line);
                tokens = line.split('\t');
                if (skipfirst)
                    skipfirst = false;
                else
                {
                    var example = { 
                        label: tokens[0], 
                        text: tokens[1],
                        };
                    var result = labeler.addExample(example);
                }
            }
            var snapshot = labeler.createSnapshot();
            console.log('Created snapshot!');
            const outputSnapshotPath = path.join(__dirname, 'snapshot', 'EmailTest_snapshot.blu');
            fs.writeFile(outputSnapshotPath, snapshot, (err) => {
                if (err) { throw err; }
                console.log('Snapshot saved!' + outputSnapshotPath);
            });
        } catch(e) {
            console.log('Error:', e.stack);
        }
    });

    it('1) should succeed creating orchestrator.', function () {
      // Initialize Orchestrator
      const nlr = new oc.Orchestrator();
      assert.notEqual(nlr, null, 'Orchestrator could not be created');
    });

    it('2) should load NLR.', function () {
        // Initialize Orchestrator
        this.timeout(1000000);
        const nlr = new oc.Orchestrator();
        const result = nlr.load();
        assert.strictEqual(result, true, 'Failed async load');
    });
    it('3) should throw load() method must provide valid path to NLR.', async function () {
        // Initialize Orchestrator
        this.timeout(600);

        const nlr = new oc.Orchestrator();
        
        assert.throws(() => { nlr.load(234); }, "TypeError: load() method must provide valid path to NLR." );
    });
    it('4) should create a LabelResolver without a NLR nodel, but with a BLU snapshot.', function () {
        this.timeout(1000000);
        const orchestrator = new oc.Orchestrator();
        console.log(`DEBUGGING - nodejs - orchestrator-core: __dirname=${__dirname}`);
        assert.ok(orchestrator.load(), 'orchestrator.load() failed');

        const snapshotPath = path.join(__dirname, 'snapshot', 'Email.blu');
        console.log(`DEBUGGING - nodejs - orchestrator-core: snapshotPath=${snapshotPath}`);
        assert.ok(fs.existsSync(snapshotPath), `snapshot file ${snapshotPath} does not exist`);

        const snapshotContent = new TextEncoder().encode(fs.readFileSync(snapshotPath, 'utf8'));
        console.log(`DEBUGGING - nodejs - orchestrator-core: snapshotContent.length=${snapshotContent.length}`);
        assert.ok(snapshotContent.length > 0, `snapshot content length is ${snapshotContent.length}`);

        const labelResolver = orchestrator.createLabelResolver(snapshotContent);
        console.log(`DEBUGGING - nodejs - orchestrator-core: labelResolver=${labelResolver}`);
        assert.ok(labelResolver !== undefined, 'cannot create a labelResolver object');

        const examples = labelResolver.getExamples();
        // console.log(`DEBUGGING - nodejs - orchestrator-core: examples=${examples}`);
        console.log(`DEBUGGING - nodejs - orchestrator-core: examples.length=${examples.length}`);
        assert.ok(examples.length === 601, `#examples is ${examples.length}`);
        const labels = labelResolver.getLabels();
        console.log(`DEBUGGING - nodejs - orchestrator-core: labels=${labels}`);
        console.log(`DEBUGGING - nodejs - orchestrator-core: labels.length=${labels.length}`);
        assert.ok(labels.length === 15, `#labels is ${labels.length}`);
        const labelsIntent = labelResolver.getLabels(1);
        console.log(`DEBUGGING - nodejs - orchestrator-core: labelsIntent=${labelsIntent}`);
        console.log(`DEBUGGING - nodejs - orchestrator-core: labelsIntent.length=${labelsIntent.length}`);
        assert.ok(labelsIntent.length === 15, `#labelsIntent is ${labelsIntent.length}`);
    });

    it('5) Add a snapshot test after creating an empty LabelResolver.', function () {
        this.timeout(1000000);

        const orchestrator = new oc.Orchestrator();
        console.log(`DEBUGGING - nodejs - orchestrator-core: __dirname=${__dirname}`);
        assert.ok(orchestrator.load(), 'orchestrator.load() failed');

        console.log('DEBUGGING - nodejs - orchestrator-core: ready to call OrchestratorHelper.getSnapshotFromFile()');
        const snapshotPath = path.join(__dirname, 'snapshot', 'Email.blu');
        console.log(`DEBUGGING - nodejs - orchestrator-core: snapshotPath=${snapshotPath}`);
        assert.ok(fs.existsSync(snapshotPath), `snapshot file ${snapshotPath} does not exist`);
        const snapshot = new TextEncoder().encode(fs.readFileSync(snapshotPath, 'utf8'));
        assert.ok(snapshot.length > 0, `snapshot content length is ${snapshot.length}`);
        console.log(`DEBUGGING - nodejs - orchestrator-core: typeof(snapshot)=${typeof snapshot}`);
        console.log(`DEBUGGING - nodejs - orchestrator-core: snapshot.byteLength=${snapshot.byteLength}`);
        console.log('DEBUGGING - nodejs - orchestrator-core: after calling OrchestratorHelper.getSnapshotFromFile()');

        const labelResolver = orchestrator.createLabelResolver();
        console.log(`DEBUGGING - nodejs - orchestrator-core: labelResolver=${labelResolver}`);
        assert.ok(labelResolver !== undefined, 'cannot create a labelResolver object');

        console.log('DEBUGGING - nodejs - orchestrator-core: ready to call LabelResolver.addSnapshot()');
        labelResolver.addSnapshot(snapshot);
        console.log('DEBUGGING - nodejs - orchestrator-core: after calling LabelResolver.addSnapshot()');

        const examples = labelResolver.getExamples();
        // console.log(`DEBUGGING - nodejs - orchestrator-core: examples=${examples}`);
        console.log(`DEBUGGING - nodejs - orchestrator-core: examples.length=${examples.length}`);
        assert.ok(examples.length === 601, `#examples is ${examples.length}`);
        const labels = labelResolver.getLabels();
        console.log(`DEBUGGING - nodejs - orchestrator-core: labels=${labels}`);
        console.log(`DEBUGGING - nodejs - orchestrator-core: labels.length=${labels.length}`);
        assert.ok(labels.length === 15, `#labels is ${labels.length}`);
        const labelsIntent = labelResolver.getLabels(1);
        console.log(`DEBUGGING - nodejs - orchestrator-core: labelsIntent=${labelsIntent}`);
        console.log(`DEBUGGING - nodejs - orchestrator-core: labelsIntent.length=${labelsIntent.length}`);
        assert.ok(labelsIntent.length === 15, `#labelsIntent is ${labelsIntent.length}`);
    });

    it('6) should throw Invalid JSON config or path provided', function () {
        this.timeout(100000);
        const nlr = new oc.Orchestrator();
        assert.throws(() => { nlr.load('/foo/bar/path'); });
        // assert.throws(() => { nlr.load('/foo/bar/path'); }, /^TypeError: Invalid JSON config or path provided: .*/);
        console.log('DEBUGGING - nodejs - orchestrator-core: after an exception caught -- 0');
    });
    
    it('7) should throw Invalid config JSON syntax in config file', function () {
        this.timeout(100000);
        expected = Error;
        const nlr = new oc.Orchestrator();
        const bad_config = path.join(__dirname, 'bad_config');
        assert.throws(() => { nlr.load(bad_config); });
        // assert.throws(() => { nlr.load(bad_config); },  /^TypeError: Invalid config JSON syntax in config file: .*/);
        console.log('DEBUGGING - nodejs - orchestrator-core: after an exception caught -- 1');
    });

    it('8) should throw Invalid or non-existent JSON config file', function () {
        this.timeout(100000);
        expected = Error;
        const nlr = new oc.Orchestrator();
        const no_config = path.join(__dirname, 'no_config');
        assert.throws(() => { nlr.load(no_config); });
        // assert.throws(() => { nlr.load(no_config); }, /^TypeError: Invalid or non-existent JSON config file: .*/);
        console.log('DEBUGGING - nodejs - orchestrator-core: after an exception caught -- 2');
    });

    it('9) Add example.', function () {
        // Arrange
        var labeler = this.orchestrator.createLabelResolver();
        const example = { 
            label: 'travel', 
            text: 'book a flight to miami.',
            };
        // Test
        const result = labeler.addExample(example);
        assert.strictEqual(result, true, 'Failed to add example');
    });
    
    it('10) Add snapshot as file.', function () {
        // Arrange
        var labeler = this.orchestrator.createLabelResolver();
        const example = { 
            label: 'travel', 
            text: 'book a flight to miami.',
            };
        var result = labeler.addExample(example);
        const snapshot = labeler.createSnapshot();
        const snapshot_file = 'snapshot.blu';
        try {
             fs.unlinkSync(snapshot_file)
        } catch(err) {
            // Swallow error
        }
        fs.appendFileSync(snapshot_file, Buffer.from(snapshot));
        // Act
        var labeler2 = this.orchestrator.createLabelResolver(); 
        result = labeler2.addSnapshot(fs.readFileSync(snapshot_file, null));
        // Assert
        assert.strictEqual(result, true, 'Failed to add snapshot');
    });

    it('11) Remove example.', function () {
        // Arrange
        var orc = new oc.Orchestrator();
        var onnx_dir = findOnnxDir(1);
        orc.load(onnx_dir);
        var labeler = orc.createLabelResolver();
        const example = { 
            label: 'travel', 
            text: 'book a flight to miami.',
            };
        
        // Test
        var result = labeler.addExample(example);
        console.log(`DEBUGGING - nodejs - orchestrator-core: after calling labeler.addExample(), result=${result}, example=${example}`);
        assert.strictEqual(result, true, 'Failed to add example');
        const example2 = { 
            label: 'travel', 
            text: 'book a flight to miami.',
            };
        result = labeler.removeExample(example2);
        console.log(`DEBUGGING - nodejs - orchestrator-core: after calling labeler.removeExample(), result=${result}, example2=${example2}`);
        assert.strictEqual(result, true, 'Failed to remove example');
    });

    it('11.5) Remove example from snapshot.', function () {
        // Arrange
        var orc = new oc.Orchestrator();
        var onnx_dir = findOnnxDir(1);
        orc.load(onnx_dir);
        var labeler = orc.createLabelResolver();
        const example = { 
            label: { 
                name: 'travel',
                span: { 
                    length: 0, 
                    offset: 0 
                },
                label_type: 1
            },
            text: 'book a flight to miami.',
        };
        var result = labeler.addExample(example);
        console.log(`DEBUGGING - nodejs - orchestrator-core: after calling labeler.addExample(), result=${result}, example=${example}`);
        assert.strictEqual(result, true, 'Failed to add example');
        var snapshot = labeler.createSnapshot();
        var labeler2 = orc.createLabelResolver(snapshot);
        
        // Test
        
        result = labeler2.removeExample(example);
        console.log(`DEBUGGING - nodejs - orchestrator-core: after calling labeler.removeExample(), result=${result}, example2=${example}`);
        assert.strictEqual(result, true, 'Failed to remove example');
        var examples = labeler2.getExamples();
        
        assert.strictEqual(examples.length, 0, 'Failed to remove example length');
    });

    it('11.6) Remove example from snapshot - JSON.', function () {
        // Arrange
        var orc = new oc.Orchestrator();
        var onnx_dir = findOnnxDir(1);
        orc.load(onnx_dir);
        var labeler = orc.createLabelResolver();
        const example = { 
            label: { 
                name: 'travel',
                span: { 
                    length: 0, 
                    offset: 5 
                },
                label_type: 1
            },
            text: 'book a flight to miami.',
        };
        var result = labeler.addExample(example);
        console.log(`DEBUGGING - nodejs - orchestrator-core: after calling labeler.addExample(), result=${result}, example=${example}`);
        assert.strictEqual(result, true, 'Failed to add example');
        let config = labeler.getConfigJson();
        let modifiedConfig = JSON.parse(config);
        modifiedConfig["prefer_tsv_snapshot"] = false;
        result = labeler.setRuntimeParams(JSON.stringify(modifiedConfig), true);
        assert.strictEqual(result, true, 'Failed to set runtime prefer JSON snapshot');

        var snapshot = labeler.createSnapshot();
        var labeler2 = orc.createLabelResolver(snapshot);
        
        // Test
        
        result = labeler2.removeExample(example);
        console.log(`DEBUGGING - nodejs - orchestrator-core: after calling labeler.removeExample(), result=${result}, example2=${example}`);
        assert.strictEqual(result, true, 'Failed to remove example');
        var examples = labeler2.getExamples();
        
        assert.strictEqual(examples.length, 0, 'Failed to remove example length');
    });

    it('12) Add example - complex label.', function () {
        // Arrange
        var labeler = this.orchestrator.createLabelResolver();
        const example =  {
            text: 'book a flight to miami.',
            labels: [ {
              name: 'travel',
              label_type: 1,
              span: {
                offset: 0,
                length: 0 } } ] };
        // Test
        var result = labeler.addExample(example);
        assert.strictEqual(result, true, 'Failed to add example');
        labeler.removeExample(example);
    });
    it('13) Add batch.', function () {
        // Arrange
        var labeler = this.orchestrator.createLabelResolver();
        // Add batch
        var batch_json = `
                    {
                        "examples":
                        [
                        {
                            "text": "Is Not Time to Be Young showing at AMC threaters",
                            "intents":
                            [
                                {
                                    "name": "movie",
                                    "offset" : 0,
                                    "length": 0
                                },
                                {
                                    "name": "question",
                                    "offset": 0,
                                    "length": 0
                                }
                            ],
                            "entities":
                            [
                                {
                                    "name": "movie_name",
                                    "offset": 3,
                                    "length": 20
                                },
                                {
                                    "name": "location_name",
                                    "offset": 35,
                                    "length": 13
                                }
                            ]
                        }
                        ]
                    }`
        const batchContent = new TextEncoder().encode(batch_json);
        // Test
        var num_new_elems = labeler.addBatch(batchContent);
        // Assert
        assert.strictEqual(num_new_elems, 1, 'Failed to add batch');
        
        var exles = labeler.getExamples();
        assert.strictEqual(exles[0].text, 'Is Not Time to Be Young showing at AMC threaters', 'text not correct');
    });
    it('14) Batch score.', function () {
        // Arrange
        var labeler = this.orchestrator.createLabelResolver();
        const example = { 
            label: 'travel', 
            text: 'book a flight to miami.',
            };

        const result = labeler.addExample(example);

        // Act
        var batch_text = [ 'hey', 'what is my schedule?', 'book a flight' ];
        var batch_results = labeler.scoreBatch(batch_text, 1);

        // Assert
        // console.log(util.inspect(batch_results, true, null, true /* enable colors */));
        assert.strictEqual(batch_results.length, 3, 'Not all results came back from batch score');
        //assert.strictEqual(batch_results[0][0].score == batch_results[1][0].score, false, 'Results should not be equal');

    });

    it('15) Invalid Add example - array using label instead of labels.', function () {
        // Arrange
        var labeler = this.orchestrator.createLabelResolver();
        const example =  {
            text: 'book a flight to miami.',
            label: [ {
              name: 'travel',
              label_type: 1,
              span: {
                offset: 0,
                length: 0 } } ] };
        // Test
        assert.throws(() => { labeler.addExample(example);});
        // assert.throws(() => { nlr.load(no_config); }, /^TypeError: Invalid or non-existent JSON config file: .*/);
        console.log('DEBUGGING - nodejs - orchestrator-core: after an exception caught -- labels plural');
    });

    it('16) Add example - lots of labels.', function () {
        // Arrange
        var labeler = this.orchestrator.createLabelResolver();
        const example =  {
            text: 'book a flight to miami.',
            labels: [ 
                { name: 'travel', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'taco', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'bell', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'kirkland', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'hungry', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'hotsauce', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'tomato', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'chocolate', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'katsuchicken', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'pulledport', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'hotpot', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'hotoil', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'dumplings', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'flavor', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'meat', label_type: 1, span: { offset: 0, length: 0 } },
                { name: 'tender', label_type: 1, span: { offset: 0, length: 0 } }
                 ] };
        // Test
        var result = labeler.addExample(example);
        assert.strictEqual(result, true, 'Failed to add example');
        labeler.removeExample(example);
    });

});

