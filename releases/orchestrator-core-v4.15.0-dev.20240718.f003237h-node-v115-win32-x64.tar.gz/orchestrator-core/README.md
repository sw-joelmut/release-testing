This package is intended for Microsoft use only. It is not designed to be consumed as an independent package. 

Click [here](https://aka.ms/bf-orchestrator) for overview of Bot Framework Orchestrator.