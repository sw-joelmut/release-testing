// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once

#include <napi.h>
#include <memory>

#include "../oc_abi/orchestrator_abi.h"

using namespace std;
using namespace Napi;


namespace oc {
class OrchestratorNode : public ObjectWrap<OrchestratorNode> {
 public:
  static Object init(Napi::Env env, Object exports);
  OrchestratorNode(const CallbackInfo& info);
  
  bool SetOrchestrator(orchestrator_t & orchestrator);

 private:
  static FunctionReference constructor;

  Napi::Value Load(const CallbackInfo& info);
  Napi::Value LoadAsync(const CallbackInfo& info);
  Napi::Value CreateLabelResolver(const Napi::CallbackInfo& info);

  orchestrator_t _orchestrator;
};
}  // namespace oc
