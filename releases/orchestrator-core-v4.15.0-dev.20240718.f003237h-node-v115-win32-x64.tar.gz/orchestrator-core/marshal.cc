// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#include <iostream>
#include <sstream>
#include <napi.h>

#include "marshal.h"
#include "validate_parameters.h"
#include "../oc_abi/orchestrator_abi.h"

#include "../utility/Debugging.h"

using namespace std;
using namespace Napi;

namespace oc 
{

    Napi::Object Marshal::CreateLabelObject(const CallbackInfo& info, const ::Label &result)
    {
        Napi::Env env = info.Env();

        auto label = Napi::Object::New(env);
        label.Set(Napi::String::New(env, "name"), Napi::String::New(env, result.name));
        label.Set(Napi::String::New(env, "label_type"), Napi::Number::New(env, result.label_type));
        auto span = Napi::Object::New(env);
        span.Set(Napi::String::New(env, "length"), Napi::Number::New(env, result.span.length));
        span.Set(Napi::String::New(env, "offset"), Napi::Number::New(env, result.span.offset));
        label.Set(Napi::String::New(env, "span"), span);
        return label;
    }

    Napi::Object Marshal::CreateExampleObject(const CallbackInfo& info, const ::Example &result)
    {
        Napi::Env env = info.Env();
        auto result_obj = Napi::Object::New(env);
        auto label_array = Napi::Array::New(env, result.label_count);
        result_obj.Set(Napi::String::New(env, "text"), Napi::String::New(env, result.text));
        for (size_t i=0; i<result.label_count; i++)
        {
            label_array[i] = CreateLabelObject(info, result.labels[i]); 
        }
        result_obj.Set(Napi::String::New(env, "labels"), label_array);
        return result_obj;
    }

    // ConvertExample supports different methods of specifying examples.
    // This determines the number of strings we need to reserve in vector and
    // reserves appropriate amount. 
    // Return value:
    //   True: strings vector is reserved for appropriate amount.
    //   False: input passed from user is invalid.
    bool Marshal::ReserveLabelStrings(const Napi::Object &src,  vector<string> & strings)
    {
        bool result = false;
        string err;
        string label_name = ValidateParameters::StringMember(src, "label", err);
        if (!label_name.empty())
        {
            // Only a single label with defaults.
            strings.reserve(3);
            result = true;
        }
        else
        {
            // Label is passed an object.
            if (src.Has("label"))
            {
                string object_err;
                auto obj = src.Get("label");
                if (!obj.IsArray())
                {
                    // Just a single label.
                    strings.reserve(3);
                    result = true;
                }
                else
                {
                    // We don't handle arrays with just label.  
                    // It needs to be "labels" (plural) - see below.
                    result = false;
                }
            }
            // Labels (plural) is passed an array.
            if (src.Has("labels"))
            {
                auto labels_obj = src.Get("labels");
                // Handle array of labels
                if (labels_obj.IsArray())
                {
                    const Napi::Array arr = labels_obj.As<Napi::Array>();
                    uint32_t count_labels = arr.Length();
                    strings.reserve(count_labels + 1);
                    result = true;
                }
            }
        }
        
        return result;


    }
    bool Marshal::ConvertExample(const Napi::Env &env, const Napi::Object &src, vector<::Label> & labels, vector<string> & strings, ::Example & dst)
    {
        bool result = false;
        // label is currently accepted in two ways.
        //   label is a string.  This is interpreted as the label name.
        //   label is an object.  Within the label object, is a field called name.
        // In the future, we may support:
        //   label as an array of string
        //   label as an array of object
        string err;

        if (!ReserveLabelStrings(src, strings))
        {
            return result;
        }
        strings.push_back(ValidateParameters::StringMember(src, "text", err));
        string label_name = ValidateParameters::StringMember(src, "label", err);

        if (!label_name.empty())
        {
            // Only a single label with defaults.
            dst.text = strings[0].c_str();
            strings.push_back(label_name);
            labels.push_back({strings[1].c_str(), static_cast<uint32_t>(::label_type::Intent), {0, 0}});
            dst.label_count = 1;
            dst.labels = labels.data();
            result = true;
        }
        else
        {
            // Label is passed an object.
            if (src.Has("label"))
            {
                string object_err;
                auto obj = src.Get("label");
                if (!obj.IsArray())
                {
                    ::Label label;
                    Napi::Object & source_label = (Napi::Object &) obj;
                    bool convert = ConvertLabel(source_label, label, strings);
                    if (convert)
                    {
                        labels.push_back(label);
                        dst.text = strings[0].c_str();
                        dst.label_count = 1;
                        dst.labels = labels.data();
                        result = true;
                    }
                    return result;
                }
                else
                {
                    // We don't handle arrays with just label.
                    return false;
                }
            }
            // Labels (plural) is passed an array.
            if (src.Has("labels"))
            {
                TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
                    "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - Marshal::ConvertExample():" <<
                    " src.Has(\"labels\") is true"
                    ););
                auto labels_obj = src.Get("labels");
                TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
                    "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - Marshal::ConvertExample():" <<
                    " labels_obj.IsArray()=" << labels_obj.IsArray()
                    ););
                // Handle array of labels
                if (labels_obj.IsArray())
                {
                    const Napi::Array arr = labels_obj.As<Napi::Array>();
                    uint32_t count_labels = arr.Length();
                    TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
                        "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - Marshal::ConvertExample():" <<
                        " count_labels=" << count_labels
                        ););
                    strings.reserve(count_labels + 1);
                    dst.label_count = count_labels;
                    TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
                        "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - Marshal::ConvertExample():" <<
                        " arr.Length()=" << arr.Length()
                        ););

                    for (size_t i=0; i<arr.Length(); i++)
                    {
                        ::Label label;
                        Napi::Object source_label = arr[i].As<Napi::Object>();
                        ConvertLabel(source_label, label, strings);
                        labels.push_back(label);
                    }

                    dst.text = strings[0].c_str();

                    dst.labels = labels.data();
                    result = true;
                }
            }
        }
        return result;
    }

    bool Marshal::ConvertLabel(const Napi::Object &srcLabel, ::Label & dstLabel, vector<string> &strings)
    {
        string name;
        size_t name_index = strings.size();
        strings.push_back(name);
        uint32_t label_type = 1;
        uint32_t offset = 0;
        uint32_t length = 0;
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - Marshal::ConvertLabel():" <<
            " srcLabel.Has(\"name\")=" << srcLabel.Has("name")
            ););
        if (srcLabel.Has("name"))
        {
            name = srcLabel.Get("name").As<Napi::String>().Utf8Value();
            TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
                "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - Marshal::ConvertLabel():" <<
                " name=" << name
                ););
            strings[name_index] = name;
        }
        else
        {
            return false;
        }

        if (srcLabel.Has("span"))
        {
            TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
                "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - Marshal::ConvertLabel():" <<
                " srcLabel.Has(\"span\") is true"
                ););
            auto span_obj = srcLabel.Get("span").As<Napi::Object>();
            offset = span_obj.Has("offset") ? span_obj.Get("offset").As<Napi::Number>().Uint32Value() : 0;
            length = span_obj.Has("length") ? span_obj.Get("length").As<Napi::Number>().Uint32Value() : 0;
        }
        if (srcLabel.Has("label_type"))
        {
            TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
                "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - Marshal::ConvertLabel():" <<
                " srcLabel.Has(\"label_type\") is true"
                ););
            label_type = srcLabel.Get("label_type").As<Napi::Number>().Uint32Value();
        }
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - Marshal::ConvertLabel():" <<
            " label_type=" << label_type
            ););

        dstLabel.name = strings[name_index].c_str();
        dstLabel.label_type = label_type;
        dstLabel.span.length = length;
        dstLabel.span.offset= offset;
        TRACE(std::clog << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - Marshal::ConvertLabel():" <<
            " dstLabel.name=" << dstLabel.name););
        TRACE(std::clog << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - Marshal::ConvertLabel():" <<
            " dstLabel.label_type=" << dstLabel.label_type););
        TRACE(std::clog << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - Marshal::ConvertLabel():" <<
            " dstLabel.span.length=" << dstLabel.span.length););
        TRACE(std::clog << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - Marshal::ConvertLabel():" <<
            " dstLabel.span.offset=" << dstLabel.span.offset););

        return true;
    }

    Napi::Object Marshal::CreateResultObject(const CallbackInfo& info, const ::Result &result)
    {
        Napi::Env env = info.Env();
        auto result_obj = Napi::Object::New(env);
        result_obj.Set(Napi::String::New(env, "closest_text"), Napi::String::New(env, result.closest_text));
        result_obj.Set(Napi::String::New(env, "score"), Napi::Number::New(env, result.score));
        auto label = Napi::Object::New(env);
        label.Set(Napi::String::New(env, "name"), Napi::String::New(env, result.label.name));
        label.Set(Napi::String::New(env, "label_type"), Napi::Number::New(env, result.label.label_type));
        auto span = Napi::Object::New(env);
        span.Set(Napi::String::New(env, "length"), Napi::Number::New(env, result.label.span.length));
        span.Set(Napi::String::New(env, "offset"), Napi::Number::New(env, result.label.span.offset));
        label.Set(Napi::String::New(env, "span"), span);
        result_obj.Set(Napi::String::New(env, "label"), label);
        return result_obj;
    }

}