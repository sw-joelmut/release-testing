// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#include <napi.h>

#include "orchestrator_node.h"
#include "label_resolver_node.h"

using namespace Napi;
using namespace oc;

Object InitAll(Env env, Object exports) 
{ 
    OrchestratorNode::init(env, exports);
    return LabelResolverNode::Init(env, exports); 
}

NODE_API_MODULE(oc, InitAll)
