// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#include <iostream>
#include <sstream>
#include <napi.h>

#ifdef _WIN32
#  include <windows.h>
#else
   typedef void* LPVOID;
#  define CoTaskMemFree(t) free(t)
#  define CoTaskMemAlloc(t) malloc(t)
#  include <string.h>
#endif 

#include <../oc.h>
#include "label_resolver_node.h"
#include "validate_parameters.h"
#include "marshal.h"
#include "../oc_abi/orchestrator_abi.h"

#include "../utility/Debugging.h"

using namespace std;
using namespace Napi;

namespace oc 
{
    FunctionReference LabelResolverNode::constructor;

    LabelResolverNode::LabelResolverNode(const CallbackInfo& info) :
        ObjectWrap<LabelResolverNode>(info)
    {
        Napi::Env env = info.Env();
        HandleScope scope(env);

        if (info.Length() == 1 && info[0].IsExternal())
        {
            oc_error_t err = 0;
            // Synchronous, single thread pass of Orchestrator to create LabelResolver.
            auto labeler_parameters = info[0].As<Napi::External<LabelResolverParams>>().Data();
            LabelResolverParams *p = labeler_parameters;
            Snapshot ss { static_cast<uint32_t>(p->snapshot.size()), p->snapshot.data() };
            _resolver = ::CreateLabelResolver(p->orchestrator, &ss, &err);
            delete p;
        }
        else
        {
            // Should never happen.  Assert.
            string error_message = "Invalid construction of LabelResolver!";
            TypeError::New(env, error_message).ThrowAsJavaScriptException();
        }
    }

    Napi::Object LabelResolverNode::NewInstance(Napi::Env env, Napi::Value arg) 
    {
        Napi::HandleScope scope(env);
        Napi::Object obj = constructor.New({ arg });
        return obj;
    }

    Napi::Object LabelResolverNode::Init(Napi::Env env, Napi::Object exports) 
    {
        HandleScope scope(env);

        auto func = DefineClass(env, "LabelResolver",
            {
                InstanceMethod("addSnapshot", &LabelResolverNode::AddSnapshot),
                InstanceMethod("createSnapshot", &LabelResolverNode::CreateSnapshot),

                InstanceMethod("addExample", &LabelResolverNode::AddExample),
                InstanceMethod("removeExample", &LabelResolverNode::RemoveExample),
                InstanceMethod("getExamples", &LabelResolverNode::GetExamples),

                InstanceMethod("getLabels", &LabelResolverNode::GetLabels),
                InstanceMethod("removeLabel", &LabelResolverNode::RemoveLabel),

                InstanceMethod("score", &LabelResolverNode::Score),

                InstanceMethod("getConfigJson", &LabelResolverNode::GetConfigJson),
                InstanceMethod("setRuntimeParams", &LabelResolverNode::SetRuntimeParams),

                InstanceMethod("addBatch", &LabelResolverNode::AddBatch),
                InstanceMethod("scoreBatch", &LabelResolverNode::ScoreBatch),

            });

        constructor = Persistent(func);
        constructor.SuppressDestruct();

        exports.Set("LabelResolver", func);
        return exports;
    }

    Napi::Value LabelResolverNode::AddSnapshot(const CallbackInfo& info)
    {
        Napi::Env env = info.Env();
        string error_message = ValidateParameters::AddSnapshot(info);
        if (!error_message.empty())
        {
            TypeError::New(env, error_message).ThrowAsJavaScriptException();
            return info.Env().Undefined();
        }

        Uint8Array buffer = info[0].As<Napi::Uint8Array>();
        string prefix = info.Length() > 1 ? info[1].ToString().Utf8Value() : "";

        const char* labelPrefix = prefix.length() > 0 ? prefix.c_str() : nullptr;

        Snapshot ss;
        ss.buffer = buffer.Data();
        ss.count = buffer.ByteLength();
        oc_error_t err = 0;
        bool result = ::AddSnapshot(_resolver, &ss, labelPrefix, &err);
        if (err != 0)
        {
            Error::New(env, GetErrorMsg(err)).ThrowAsJavaScriptException();
            return info.Env().Undefined();
        }

        return Boolean::New(env, result);
    }

    Napi::Value LabelResolverNode::AddBatch(const CallbackInfo& info)
    {
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::AddBatch():" <<
            " ENTERING"
            ););

        Napi::Env env = info.Env();
        Napi::Uint8Array batchUint8Array;
        string labelsPrefix;
        batch_option option;

        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::AddBatch():" <<
            " before calling ValidateParameters::AddBatch():" <<
            " info.Length()=" << info.Length()
            ););
        string error_message = ValidateParameters::AddBatch(info, batchUint8Array, labelsPrefix, option);
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::AddBatch():" <<
            " after calling ValidateParameters::AddBatch():" <<
            " info.Length()=" << info.Length() <<
            ", error_message=" << error_message
            ););
        if (!error_message.empty())
        {
            TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
                "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::AddBatch():" <<
            	" info.Length()=" << info.Length() <<
                ", error_message='" << error_message << "'"
                ););

            TypeError::New(env, error_message).ThrowAsJavaScriptException();
            return env.Undefined();
        }

        Snapshot batchBuffer;
        batchBuffer.buffer = batchUint8Array.Data();
        batchBuffer.count = batchUint8Array.ByteLength();
        oc_error_t err = 0;
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::AddBatch():" <<
            " before calling ::AddBatch:" <<
            " info.Length()=" << info.Length() <<
            " batchBuffer.count=" << batchBuffer.count
            ););
        int32_t new_elements = ::AddBatch(_resolver, &batchBuffer, labelsPrefix.c_str(), option, &err);
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::AddBatch():" <<
            " after calling ::AddBatch:" <<
            " info.Length()=" << info.Length() <<
            " batchBuffer.count=" << batchBuffer.count
            ););
        if (err != 0)
        {
            TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
                "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::AddBatch():" <<
                " error=" << err <<
                " labelsPrefix=" << labelsPrefix
                ););

            Error::New(env, GetErrorMsg(err, 0)).ThrowAsJavaScriptException();
            return env.Undefined();
        }

        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::AddBatch():" <<
            " LEAVING"
            ););
        return Number::New(env, (double) new_elements);
    }

    Napi::Value LabelResolverNode::AddExample(const CallbackInfo& info)
    {
        Napi::Env env = info.Env();
        oc_error_t err = 0;
        Napi::Object label;
        string error_message = ValidateParameters::AddExample(info, label);
        if (!error_message.empty())
        {
            TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
                "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::AddExample():" <<
                " error=" << error_message
                ););
            TypeError::New(env, error_message).ThrowAsJavaScriptException();
            return info.Env().Undefined();
        }

        auto example = info[0].As<Napi::Object>();
        ::Example converted_example; 
        vector<::Label> labels;
        vector<string> strings;
        if (!Marshal::ConvertExample(env, example, labels, strings, converted_example))
        {
            error_message = "Could not convert example";
            Error::New(env, error_message).ThrowAsJavaScriptException();
            return env.Undefined();
        }

        bool result = ::AddExample(_resolver, &converted_example, &err);
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::AddExample():" <<
            " after calling ::AddExample(), result=" << result
            ););
        if (err != 0)
        {
            Error::New(env, GetErrorMsg(err)).ThrowAsJavaScriptException();
            return info.Env().Undefined();
        }

        return Boolean::New(env, result);
    }

    Napi::Value LabelResolverNode::CreateSnapshot(const CallbackInfo& info)
    {
        Napi::Env env = info.Env();

        string error_message = ValidateParameters::CreateSnapshot(info);
        if (!error_message.empty())
        {
            TypeError::New(env, error_message).ThrowAsJavaScriptException();
            return info.Env().Undefined();
        }

        oc_error_t err = 0;
        bool include_examples = (info.Length() == 1) ? info[0].As<Napi::Boolean>() : true;

        // Call async API
        Snapshot *ss = nullptr;
        resource_t resources = 0;
        ::CreateSnapshot(_resolver, &ss, include_examples, &resources, &err);
        if (err != 0)
        {
            Error::New(env, GetErrorMsg(err, resources)).ThrowAsJavaScriptException();
            return info.Env().Undefined();
        }
        auto result = Napi::Uint8Array::New(env, ss->count, napi_uint8_array);
        std::memcpy(result.Data(), ss->buffer, ss->count);

        ResourceRelease(resources);

        return result;
    }

    Napi::Value LabelResolverNode::RemoveExample(const CallbackInfo& info)
    {
        Napi::Env env = info.Env();
        oc_error_t err = 0;
        Napi::Object label;

        string error_message = ValidateParameters::RemoveExample(info, label);
        if (!error_message.empty())
        {
            TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
                "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::RemoveExample():" <<
                " error=" << error_message
                ););
            TypeError::New(env, error_message).ThrowAsJavaScriptException();
            return info.Env().Undefined();
        }

        auto example = info[0].As<Napi::Object>();
        ::Example converted_example; 
        vector<::Label> labels;
        vector<string> strings;
        if (!Marshal::ConvertExample(env, example, labels, strings, converted_example))
        {
            error_message = "Could not convert example";
            Error::New(env, error_message).ThrowAsJavaScriptException();
            return env.Undefined();
        }

        bool result = ::RemoveExample(_resolver, &converted_example, &err);
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::RemoveExample():" <<
            " after calling ::RemoveExample(), result=" << result
            ););
        if (err != 0)
        {
            Error::New(env, GetErrorMsg(err)).ThrowAsJavaScriptException();
            return info.Env().Undefined();
        }

        return Boolean::New(env, result);
    }

    Value LabelResolverNode::RemoveLabel(const CallbackInfo& info)
    {
        Napi::Env env = info.Env();
        size_t length = info.Length();
        if (length != 1)
        {
            string error_message = "RemoveLabel() requires label name as parameter";
            TypeError::New(env, error_message).ThrowAsJavaScriptException();
            return env.Undefined();
        }

        string label = info[0].As<Napi::String>();
        oc_error_t err = 0;

        bool result = ::RemoveLabel(_resolver, label.c_str(), &err);
        if (err != 0)
        {
            Error::New(env, GetErrorMsg(err)).ThrowAsJavaScriptException();
            return env.Undefined();
        }

        return Boolean::New(env, result);
    }

    Value LabelResolverNode::GetExamples(const CallbackInfo& info)
    {
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::GetExamples():" <<
            " info.Length()=" << info.Length()
            ););

        Napi::Env env = info.Env();
        
        string label_name;
        uint32_t label_type = static_cast<uint32_t>(static_cast<uint32_t>(label_type::All));

        string error_message = ValidateParameters::GetExamples(info, label_name, label_type);
        if (!error_message.empty())
        {
            TypeError::New(env, error_message).ThrowAsJavaScriptException();
            return env.Undefined();
        }

        oc_error_t err = 0;
        resource_t resources = 0;
        Examples* results = nullptr;

        ::GetExamples(_resolver, label_name.c_str(), label_type, &results, &resources, &err);

        if (err != 0)
        {
            Error::New(env, GetErrorMsg(err, resources)).ThrowAsJavaScriptException();
            return env.Undefined();
        }

        auto result_array = Napi::Array::New(env, results->count);
        for (size_t i=0; i<results->count; i++)
        {
            result_array[i] = Marshal::CreateExampleObject(info, results->examples[i]);
        }

        ResourceRelease(resources);

        return result_array;
    }

    Value LabelResolverNode::GetLabels(const CallbackInfo& info)
    {
        Napi::Env env = info.Env();
        
        uint32_t label_type = static_cast<uint32_t>(1);
        string error_message = ValidateParameters::GetLabels(info, label_type);
        if (!error_message.empty())
        {
            TypeError::New(env, error_message).ThrowAsJavaScriptException();
            return env.Undefined();
        }

        oc_error_t err = 0;
        resource_t resources = 0;
        Labels* results = nullptr;

        ::GetLabels(_resolver, label_type, &results, &resources, &err);
        if (err != 0)
        {
            Error::New(env, GetErrorMsg(err, resources)).ThrowAsJavaScriptException();
            return env.Undefined();
        }

        auto result_array = Napi::Array::New(env, results->count);
        for (size_t i=0; i<results->count; i++)
        {
            result_array[i] = Napi::String::New(env, results->labels[i]);
        }
        ::ResourceRelease(resources);

        return result_array;
    }

    Napi::Value LabelResolverNode::Score(const CallbackInfo& info)
    {
        Napi::Env env = info.Env();
        string text;
        uint32_t label_type = static_cast<uint32_t>(1); // static_cast<uint32_t>(Intent);

        string error_message = ValidateParameters::Score(info, text, label_type);
        if (!error_message.empty())
        {
            TypeError::New(env, error_message).ThrowAsJavaScriptException();
            return info.Env().Undefined();
        }

        oc_error_t err = 0;
        resource_t resources = 0;
        Results* results = nullptr;

        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::Score()-BEFORE:" <<
            " info.Length()=" << info.Length() <<
            ", label_type=" << label_type
            ););
        ::Score(_resolver, text.c_str(), label_type, &results, &resources, &err);
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::Score()-AFTER:" <<
            " info.Length()=" << info.Length() <<
            ", label_type=" << label_type <<
            ", err=" << err <<
            ", results->count=" << results->count
            ););
        if (err != 0)
        {
            Error::New(env, GetErrorMsg(err, resources)).ThrowAsJavaScriptException();
            return info.Env().Undefined();
        }

        auto result_array = Napi::Array::New(env, results->count);
        for (size_t i=0; i<results->count; i++)
        {
            result_array[i] = Marshal::CreateResultObject(info, results->results[i]);
        }

        ResourceRelease(resources);

        return result_array;
    }

    Napi::Value LabelResolverNode::ScoreBatch(const CallbackInfo& info)
    {
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::ScoreBatch():" <<
            " ENTERING" <<
            " info.Length()=" << info.Length()
            ););
        Napi::Env env = info.Env();
        TextStrings text;
        vector<string> string_buffers;
        uint32_t lab_type = static_cast<uint32_t>(1);

        string error_message = ValidateParameters::ScoreBatch(info, text, string_buffers, lab_type);
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::ScoreBatch():" <<
            " ready to call ::ScoreBatch(): " <<
            " info.Length()=" << info.Length() <<
            ", lab_type=" << lab_type <<
            ", text.text=" << text.text <<
            ", text.count=" << text.count <<
            ", error_message='" << error_message << "'" <<
            ", string_buffers.size()=" << string_buffers.size()
            ););
        if (!error_message.empty())
        {
            TypeError::New(env, error_message).ThrowAsJavaScriptException();
            return info.Env().Undefined();
        }

        oc_error_t err = 0;
        resource_t resources = 0;
        BatchResults* results = nullptr;
        
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::ScoreBatch():" <<
            " ready to call ::ScoreBatch(): " <<
            " info.Length()=" << info.Length() <<
            ", lab_type=" << lab_type <<
            ", text.text=" << text.text <<
            ", text.count=" << text.count <<
            ", err=" << err <<
            ", string_buffers.size()=" << string_buffers.size()
            ););
        bool result = ::ScoreBatch(_resolver, &text, static_cast<label_type>(lab_type), &results, &resources, &err);
        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::ScoreBatch():" <<
            " finished calling ::ScoreBatch(): " <<
            " info.Length()=" << info.Length() <<
            ", lab_type=" << lab_type <<
            ", text.text=" << text.text <<
            ", text.count=" << text.count <<
            ", err=" << err <<
            ", results=" << results <<
            ", string_buffers.size()=" << string_buffers.size()
            ););
        if (err != 0)
        {
            Error::New(env, GetErrorMsg(err, resources)).ThrowAsJavaScriptException();
            delete [] text.text;
            return info.Env().Undefined();
        }

        auto batch_results = Napi::Array::New(env, results->count);
        for (size_t i=0; i<results->count; i++)
        {
            auto result = results->results[i];
            auto inner_results = Napi::Array::New(env, result.count);
            for (size_t x=0; x<result.count; x++)
            {
                inner_results[x] = Marshal::CreateResultObject(info, result.results[x]);
            }
            batch_results[i] = inner_results;
        }
        delete [] text.text;
        ResourceRelease(resources);

        TRACE(std::cerr << STRINGSTREAM_TO_TIMESTAMPED_STRING_WITH_FILE_LINE_ENDL(
            "DEBUGGING - NODEJS - ORCHESTRATOR-CORE - LabelResolverNode::ScoreBatch():" <<
            " LEAVING" <<
            " info.Length()=" << info.Length()
            ););
        return batch_results;
    }

    string LabelResolverNode::GetErrorMsg(oc_error_t err, resource_t resource)
    {
        const char* err_msg_ptr = ::ErrorMessage(err);
        string result = err_msg_ptr;
        CoTaskMemFree((LPVOID) err_msg_ptr);
        ::ErrorRelease(err);
        if (resource != 0)
        {
            ::ResourceRelease(resource);
        }
        return result;
    }

    Value LabelResolverNode::GetConfigJson(const CallbackInfo& info)
    {
        Napi::Env env = info.Env();
        
        oc_error_t err = 0;

        char* result_ptr = ::GetConfigJson(_resolver, &err);
        string result = result_ptr;
        if (nullptr != result_ptr)
        {
            CoTaskMemFree(result_ptr);
        }
        if (err != 0)
        {
            Error::New(env, GetErrorMsg(err)).ThrowAsJavaScriptException();
            return env.Undefined();
        }

        return Napi::String::New(env, result);
    }

    Value LabelResolverNode::SetRuntimeParams(const CallbackInfo& info)
    {
        Napi::Env env = info.Env();
        
        oc_error_t err = 0;
        string config_or_path = "";
        bool reset_all = false;
        string error_message = ValidateParameters::SetRuntimeParams(info, config_or_path, reset_all);
        if (!error_message.empty())
        {
            TypeError::New(env, error_message).ThrowAsJavaScriptException();
            return env.Undefined();
        }
        
        bool result = ::SetRuntimeParams(_resolver, config_or_path.c_str(), reset_all, &err);
        if (!result)
        {
            if (err != 0)
            {
                Error::New(env, GetErrorMsg(err)).ThrowAsJavaScriptException();
                return env.Undefined();
            }
        }

        return Napi::Boolean::New(env, result);
    }

    // https://github.com/nodejs/abi-stable-node-addon-examples/issues/17
    LabelResolverNode::~LabelResolverNode()
    {
        if (0 != _resolver)
        {
            ::ReleaseLabelResolver(_resolver);
        }
    }

} // namespace oc