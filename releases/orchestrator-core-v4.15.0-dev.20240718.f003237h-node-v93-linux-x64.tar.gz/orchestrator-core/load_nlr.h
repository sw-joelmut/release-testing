// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once
#include <napi.h>

#include "orchestrator_node.h"
#include "../oc_abi/ioc.h"

using namespace std;
using namespace Napi;
using namespace Microsoft::Orchestrator;

namespace oc {
class LoadNlrWorker : public AsyncWorker {
    
    public:
        LoadNlrWorker(Napi::Env &env, const string &intentBaseModelPathOrConfig, OrchestratorNode& orchestrator);
        LoadNlrWorker(Napi::Env &env, const string &intentBaseModelPathOrConfig, const string &entityBaseModelPathOrConfig, OrchestratorNode& orchestrator);
        virtual ~LoadNlrWorker() {};

        void Execute();
        void OnOK();
        void OnError(Napi::Error const &error);

        Napi::Promise GetPromise() { return _deferred.Promise(); }

    private:
        string _intentBaseModelPathOrConfig;
        string _entityBaseModelPathOrConfig;
        Napi::ObjectReference _orchestrator_reference; // Figure out how to keep reference
        OrchestratorNode &_orchestrator;
        bool _result;
        Promise::Deferred _deferred;
};
}