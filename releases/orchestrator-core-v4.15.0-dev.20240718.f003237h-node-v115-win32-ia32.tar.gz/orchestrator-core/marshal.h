// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once
#include <napi.h>
#include <memory>
#include "../oc_abi/orchestrator_abi.h"
using namespace std;
using namespace Napi;

namespace oc 
{
    class Marshal
    {
        public:
            static Napi::Object CreateLabelObject(const CallbackInfo& info, const ::Label &result);
            static Napi::Object CreateExampleObject(const CallbackInfo& info, const ::Example &result);
            static Napi::Object CreateResultObject(const CallbackInfo& info, const ::Result &result);
            static bool ConvertExample(const Napi::Env &env, const Napi::Object &src, vector<::Label> & labels, vector<string> & strings, ::Example & dst);
            static bool ConvertLabel(const Napi::Object &srcLabel, ::Label & dstLabel, vector<string> &strings);
            static bool ReserveLabelStrings(const Napi::Object &src,  vector<string> & strings);
    };
}
