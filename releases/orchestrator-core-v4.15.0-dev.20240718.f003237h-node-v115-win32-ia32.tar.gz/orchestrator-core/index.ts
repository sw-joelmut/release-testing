/**
 * @module oc_node
 */
/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
var addon = require('bindings')('orchestrator-core');