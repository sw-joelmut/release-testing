// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#include <stdexcept>
#include <napi.h>

#include "load_nlr.h"
#include "../oc_abi/orchestrator_abi.h"

using namespace std;
using namespace Napi;


namespace oc {

LoadNlrWorker::LoadNlrWorker(Napi::Env &env, const string &intentBaseModelPathOrConfig, OrchestratorNode& orchestrator) 
    : AsyncWorker(env), _intentBaseModelPathOrConfig(intentBaseModelPathOrConfig), _orchestrator(orchestrator), _deferred(Promise::Deferred::New(env))
{
}
LoadNlrWorker::LoadNlrWorker(Napi::Env &env, const string &intentBaseModelPathOrConfig, const string &entityBaseModelPathOrConfig, OrchestratorNode& orchestrator) 
    : AsyncWorker(env), _intentBaseModelPathOrConfig(intentBaseModelPathOrConfig), _entityBaseModelPathOrConfig(entityBaseModelPathOrConfig), _orchestrator(orchestrator), _deferred(Promise::Deferred::New(env))
{
}

void LoadNlrWorker::Execute() 
{
    oc_error_t err = 0;
    orchestrator_t orch_type = (_entityBaseModelPathOrConfig.size() <= 0) ?
        ::CreateOrchestratorAbi(_intentBaseModelPathOrConfig.c_str(), &err) :
        ::CreateOrchestratorAbiIntentEntity(_intentBaseModelPathOrConfig.c_str(), _entityBaseModelPathOrConfig.c_str(), &err);
    if (err != 0)
    {
        Napi::AsyncWorker::SetError(::ErrorMessage(err));
        ::ErrorRelease(err);
        return;
    }

    _orchestrator.SetOrchestrator(orch_type);
    _result = true;
};

void LoadNlrWorker::OnError(Napi::Error const &error) 
{
    _deferred.Reject(error.Value());
}
void LoadNlrWorker::OnOK() 
{
    auto result =  Napi::Boolean::New(Env(), _result);
    _deferred.Resolve(result);
};

} // namespace oc